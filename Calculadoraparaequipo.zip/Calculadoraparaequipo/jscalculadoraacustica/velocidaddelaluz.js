function calcularindicerefr(){
    
                    const velovacion = parseFloat(document.getElementById('velovacion').value);
                    const velomedio = parseFloat(document.getElementById('velomedio').value);
                
                    if (isNaN(velovacion|| isNaN(velomedio))) {
                        alert('Por favor, ingrese valores numéricos válidos.');
                        return;
                    }
                    
                    const indicederefraccion = velovacion/velomedio;
                    document.getElementById('resultindicer').textContent = `La Frecuecia de la onda es de: ${indicederefraccion}`;
                
                
                    }
                    function calcularvelocidadvacion(){
    
                        const indirefra = parseFloat(document.getElementById('indirefra').value);
                        const velomedio2 = parseFloat(document.getElementById('velomedio2').value);
                    
                        if (isNaN(indirefra|| isNaN(velomedio2))) {
                            alert('Por favor, ingrese valores numéricos válidos.');
                            return;
                        }
                        
                        const velocidadDeLaLuzz = indirefra*velomedio2;
                        document.getElementById('resultvelovacio').textContent = `La Frecuecia de la onda es de: ${velocidadDeLaLuzz}`;
                    
                    
                        }
                        function calcularlaluzenunmedio(){
    
                            const velovacio4 = parseFloat(document.getElementById('velovacio4').value);
                            const indicederefra4 = parseFloat(document.getElementById('indicederefra4').value);
                        
                            if (isNaN(velovacio4|| isNaN(indicederefra4))) {
                                alert('Por favor, ingrese valores numéricos válidos.');
                                return;
                            }
                            
                            const velocidadelaluzenmedio = velovacio4/indicederefra4;
                            document.getElementById('resultvelomedio').textContent = `La Frecuecia de la onda es de: ${velocidadelaluzenmedio}`;
                        
                        
                            }