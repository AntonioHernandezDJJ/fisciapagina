// Función para calcular la longitud de onda
function calcularLongitudDeOnda() {
    // Obtener el valor de la frecuencia desde el input
    const frecuencia = parseFloat(document.getElementById('frecuencia').value);

    if (isNaN(frecuencia)) {
        alert('Por favor, ingrese una frecuencia válida.');
        return;
    }

    // Velocidad de la luz en el vacío en metros por segundo
    const velocidadDeLaLuz = 3.00e8;

    // Calcular la longitud de onda usando la fórmula λ = c / f
    const longitudDeOnda = velocidadDeLaLuz / frecuencia;

    // Mostrar el resultado en el elemento con id "resultado"
    document.getElementById('resultado').textContent = `Para una frecuencia de ${frecuencia.toExponential()} Hz, la longitud de onda calculada es ${longitudDeOnda.toExponential()} metros.`;
}
//CALCULA EL PERIODO..
function calcularfrecuencia(){
    const periodo = parseFloat(document.getElementById('periodo').value);
    if (isNaN(periodo)) {
        alert('Por favor, ingrese un periodo válida.');
        return;
    }

    const numero = 1;
  
    // Calcular la longitud de onda usando la fórmula λ = c / f
    const periododelaonda = numero / periodo;
    document.getElementById('resultadofr').textContent = `El periodo es de ${periododelaonda.toExponential()} `;


}

function calcularfrangular(){
    const frangular = parseFloat(document.getElementById('frangular').value);
    if (isNaN(frangular)) {
        alert('Por favor, ingrese una frecuencia válida.');
        return;
    }
    const dosfr = 2;
    const pii = 3.1416;

    // Calcular la longitud de onda usando la fórmula λ = c / f
    const frangularfinal = dosfr * pii * frangular;
    document.getElementById('resultadofra').textContent = `El resultado es de ${frangularfinal.toExponential()} `;



}    

function calcularnumonda(){
    const numonda = parseFloat(document.getElementById('numonda').value);
    if (isNaN(numonda)) {
        alert('Por favor, ingrese un numero válida.');
        return;
    }
    const dosfr = 2;
    const pii = 3.1416;

    const doesspii = dosfr * pii;
    const numondass = doesspii/numonda;
    document.getElementById('resultadonumondas').textContent = `La frecuencia es de ${numondass.toExponential()} `;



}  





function calcularEcuacionOnda() {
    // Obtener los valores desde los inputs
    const amplitudd = parseFloat(document.getElementById('amplitudd').value);
    const frecuenciaaaa = parseFloat(document.getElementById('frecuenciaaaa').value);
    const numeroOndaaa = parseFloat(document.getElementById('numeroOndaaa').value);
    const faseIniciaaal = parseFloat(document.getElementById('faseIniciaaal').value);

    // Verificar si los valores son números válidos
    if (isNaN(amplitudd) || isNaN(frecuenciaaaa) || isNaN(numeroOndaaa) || isNaN(faseIniciaaal)) {
        alert('Por favor, ingrese valores numéricos válidos.');
        return;
    }

    // Construir la ecuación de onda armónica
    const ecuacion = `y(x, t) = ${amplitudd} * sin(2π * ${frecuenciaaaa} * t - ${numeroOndaaa} * x + ${faseIniciaaal})`;

    // Mostrar el resultado en el elemento con id "ecuacionResultado"
    document.getElementById('ecuacionResultado').textContent = `Resultado: ${ecuacion}`;
}

function calcularamplituddeonda() {
    // Obtener los valores desde los inputs
    const ampli04 = parseFloat(document.getElementById('ampli04').value);
    const veloanguw = parseFloat(document.getElementById('veloanguw').value);
    

    // Verificar si los valores son números válidos
    if (isNaN(ampli04) || isNaN(veloanguw)) {
        alert('Por favor, ingrese valores numéricos válidos.');
        return;
    }

    // Construir la ecuación de onda armónica
    const ecuacion = `y(t) = ${ampli04} * sin(2π * ${veloanguw} * t)`;

    // Mostrar el resultado en el elemento con id "ecuacionResultado"
    document.getElementById('resulamplondas').textContent = `La ecuación es: ${ecuacion}`;
}