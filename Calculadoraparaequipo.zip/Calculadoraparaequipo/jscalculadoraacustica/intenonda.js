function calcularlainteonda() {
    // Obtener los valores desde los inputs
    const ampli22 = parseFloat(document.getElementById('ampli22').value);
    const frecuangular22 = parseFloat(document.getElementById('frecuangular22').value);
    const densilineal2 = parseFloat(document.getElementById('densilineal2').value);
    const veloangular2 = parseFloat(document.getElementById('veloangular2').value);

    // Verificar si los valores son números válidos
    if (isNaN(ampli22) || isNaN(frecuangular22) || isNaN(densilineal2) || isNaN(veloangular2)) {
        alert('Por favor, ingrese valores numéricos válidos.');
        return;
    }

    const elea = ampli22 * ampli22;
    const elew = frecuangular22 * frecuangular22;
    const ecuacionfinal = 0.5 * densilineal2 * elew *elea * veloangular2 ;

    // Mostrar el resultado en el elemento con id "ecuacionResultado"
    document.getElementById('resultinteonda').textContent = `Resultado: ${ecuacionfinal} W/m^2`;
}

function calcularcompresibilidad(){

    const compresiniagua = parseFloat(document.getElementById('compresiniagua').value);
    const densidadagua = parseFloat(document.getElementById('densidadagua').value);
    if (isNaN(compresiniagua) || isNaN(densidadagua)) {
        alert('Por favor, ingrese valores numéricos válidos.');
        return;

    }
    const resuldivi = compresiniagua/densidadagua;
    const velocidadfinalll = Math.sqrt(resuldivi);
    document.getElementById('resulcompre').textContent = `Resultado: ${velocidadfinalll}`;

}