function Calcularfrecuenciadeonda(){
    
    const longonda = parseFloat(document.getElementById('longonda').value);
    const velonda = parseFloat(document.getElementById('velonda').value);

    if (isNaN(longonda) || isNaN(velonda)) {
        alert('Por favor, ingrese valores numéricos válidos.');
        return;
    }
    const frecuenciaaonda = velonda/longonda;
    document.getElementById('resultadofrecuenciaa').textContent = `La Frecuecia de la onda es de: ${frecuenciaaonda} hz`;


    }

    function Calcularvelocidad(){
    
        const longonda2 = parseFloat(document.getElementById('longonda2').value);
        const frelonda2 = parseFloat(document.getElementById('frelonda2').value);
    
        if (isNaN(longonda2) || isNaN(frelonda2)) {
            alert('Por favor, ingrese valores numéricos válidos.');
            return;
        }
        const velocidaddelaonda = frelonda2/longonda2;
        document.getElementById('resultadovelocidadonda').textContent = `La Frecuecia de la onda es de: ${velocidaddelaonda}`;
    
    
        }
        function Calcularlongitud(){
    
            const veloonda2 = parseFloat(document.getElementById('veloonda2').value);
            const frelonda3 = parseFloat(document.getElementById('frelonda3').value);
        
            if (isNaN(veloonda2) || isNaN(frelonda3)) {
                alert('Por favor, ingrese valores numéricos válidos.');
                return;
            }
            const longitudonda = veloonda2/frelonda3;
            document.getElementById('resultadolongonda').textContent = `La longitud de la onda es de: ${longitudonda} m`;
        
        
            }
            function Calcularfreangulaar(){
    
                const frecuencia4 = parseFloat(document.getElementById('frecuencia4').value);
                
            
                if (isNaN(frecuencia4)) {
                    alert('Por favor, ingrese valores numéricos válidos.');
                    return;
                }
                const pii = 3.1416
                const frecuenciadelaondaa = 2* pii *frecuencia4;
                document.getElementById('resulfrecuonda').textContent = `La Frecuecia de la onda es de: ${frecuenciadelaondaa}`;
            
            
                }
                function Calcularfrecuw(){
    
                    const frecuenciaw = parseFloat(document.getElementById('frecuenciaw').value);
                    
                
                    if (isNaN(frecuenciaw)) {
                        alert('Por favor, ingrese valores numéricos válidos.');
                        return;
                    }
                    const does = 2;
                    const pii = 3.1416
                    const dospi = does*pii
                    const frecuencianormaldelaonda = frecuenciaw/dospi;
                    document.getElementById('resulfrecuw').textContent = `La Frecuecia de la onda es de: ${frecuencianormaldelaonda}`;
                
                
                    }

                    function Calcularnumonda(){
    
                        const longonda333 = parseFloat(document.getElementById('longonda333').value);
                        
                    
                        if (isNaN(longonda333)) {
                            alert('Por favor, ingrese valores numéricos válidos.');
                            return;
                        }
                        const does = 2;
                        const pii = 3.1416
                        const dospi = does*pii
                        const nummondaaa = dospi/longonda333;
                        document.getElementById('resulnumonda').textContent = `El numero de onda: ${nummondaaa} rad/m        `;
                    
                    
                        }